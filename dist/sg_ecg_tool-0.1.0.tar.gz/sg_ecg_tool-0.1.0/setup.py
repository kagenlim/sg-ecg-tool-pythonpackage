# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['sg_ecg_tool']

package_data = \
{'': ['*']}

install_requires = \
['matplotlib>=3.3.3,<4.0.0',
 'pandas>=1.1.5,<2.0.0',
 'pytest>=6.2.1,<7.0.0',
 'requests>=2.25.1,<3.0.0']

setup_kwargs = {
    'name': 'sg-ecg-tool',
    'version': '0.1.0',
    'description': 'Python package that generates statistics on higher education and employment, for Singaporean students.',
    'long_description': None,
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
